--Asssumptions: 
--this is a mom and pop facility where the only employees are the owners, eliminating the need for additional staff and store tables. 

CREATE DATABASE vet_clinic;

CREATE TABLE owner
(
        
	owner_id serial,                               
	last_Name varchar(50) not null,
	first_Name varchar(50) not null,
	street_address varchar(50) not null,
	city varchar(50) not null,
	state_id varchar(5) not null,
	zip_code varchar(10) not null,
	
	constraint pk_owner_id primary key (owner_id),
);



CREATE TABLE pet
(
	pet_id serial,
	pet_name varchar(20) not null,
	pet_type varchar(20) not null,
	pet_age int,

	constraint pk_pet_id primary key (pet_id)
);

CREATE TABLE pet_owner
(
	owner_id serial,
	pet_id int not null,
	
	
	constraint pk_pet_owner_id primary key (pet_id, owner_id),
	constraint fk_pet_id foreign key (pet_id) references pet(pet_id),
	constraint fk_owner_id foreign key (owner_id) references owner(owner_id)
);

CREATE TABLE procedure
(
	procedure_id serial,
	name_of_procedure varchar(50) not null,
	amount_procedure decimal (7,2) not null,
	
	constraint pk_procedure_id primary key (procedure_id)
	
);

CREATE TABLE pet_procedure
(
	pet_id serial,
	procedure_id int not null,
	

	constraint pk_pet_procedure_id primary key (pet_id, procedure_id),
	constraint fk_pet_id foreign key (pet_id) references procedure(procedure_id),
	constraint fk_procedure_id foreign key (procedure_id) references procedure(procedure_id)
);

CREATE TABLE invoice
(
	invoice_id serial,
	procedure_id int not null,
	name_of_procedure varchar(50) not null,
	date_of_procedure varchar(10) not null,
	
	constraint pk_invoice_id primary key (invoice_id),
	constraint fk_procedure_id foreign key (procedure_id) references procedure (procedure_id)
);


insert into procedure(name_of_procedure, amount_procedure) values ('Office exam', 20.00);
insert into procedure(name_of_procedure, amount_procedure) values ('Declaw', 1000.00);
insert into procedure(name_of_procedure, amount_procedure) values ('Flea Removal', 30.00);
insert into procedure(name_of_procedure, amount_procedure) values ('Vaccine', 200.00);

insert into owner (last_name, first_name, street_address, city, state_id, zip_code)  values ('Smith', 'John', '111 First Ave', 'Columbus', 'OH', '43214');
insert into owner (last_name, first_name, street_address, city, state_id, zip_code)  values ('Dope', 'Jim', '112 First Ave', 'Columbus', 'OH', '43214');
insert into owner (last_name, first_name, street_address, city, state_id, zip_code)  values ('Poppins', 'Mary', '113 First Ave', 'Columbus', 'OH', '43214');

insert into pet (pet_name, pet_type, pet_age) values ('Fluffy', 'Snake', 4);
insert into pet (pet_name, pet_type, pet_age) values ('Killer', 'Cat', 2);
insert into pet (pet_name, pet_type, pet_age) values ('Bowser', 'Dog', 3);

insert into pet_owner(owner_id, pet_id) values (2,1);
insert into pet_owner(owner_id, pet_id) values (2,2);
insert into pet_owner(owner_id, pet_id) values (4,3);



select*
from procedure;