package com.techelevator.campground.model;

import java.util.List;

public interface ParkDAO {

	List<Park>getAllParks();

	//List<Park>searchByParkId(Long id);

}
