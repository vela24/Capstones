package com.techelevator.campground.model.jdbc;

public class JDBCSiteDAO {

}
