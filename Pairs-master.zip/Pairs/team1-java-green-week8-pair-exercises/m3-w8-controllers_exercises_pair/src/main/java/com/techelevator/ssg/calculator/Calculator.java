package com.techelevator.ssg.calculator;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;

public class Calculator {
	private Map<String, Double> planetMap;
	private Map<String, Double> travelMap;
	
	public String alienAge(String planet, Double age) {
		DecimalFormat df = new DecimalFormat("#,###.00");
		planetMap = new HashMap<String, Double>();
		planetMap.put("mercury", 87.96);
		planetMap.put("venus", 224.68);
		planetMap.put("mars", 686.98);
		planetMap.put("jupiter", 4332.71);
		planetMap.put("saturn", 10759.09);
		planetMap.put("uranus",30707.40);
		planetMap.put("neptune", 60198.50);
		Double years = (age * 365.26) / planetMap.get(planet);
		
		
		String result = "If you are " + Math.round(age) + " years old on planet Earth, then you are " + df.format(years) + " " + planet.substring(0, 1).toUpperCase() + planet.substring(1) + " years old.";
		return result;
	}
	
	public String alienWeight(String planet, Double lbsOnEarth) {
		DecimalFormat df = new DecimalFormat("#,###.00");
		planetMap = new HashMap<String, Double>();
		planetMap.put("mercury", .37);
		planetMap.put("venus", .90);
		planetMap.put("mars", .38);
		planetMap.put("jupiter", 2.65);
		planetMap.put("saturn", 1.13);
		planetMap.put("uranus", 1.09);
		planetMap.put("neptune", 1.43);
		Double newWeight = lbsOnEarth * planetMap.get(planet);
		
		String result = "If you are " + Math.round(lbsOnEarth) + " lbs on planet Earth, you would weigh " + df.format(newWeight) + " lbs on " + planet.substring(0, 1).toUpperCase() + planet.substring(1) + ".";
		return result;
	}
	
	public String driveTime(String planet, String methodOfTransportation, Double age) {
		DecimalFormat df = new DecimalFormat("#,###.00");
		planetMap = new HashMap<String, Double>();
		planetMap.put("mercury", 56974146.0);
		planetMap.put("venus", 25724767.0);
		planetMap.put("mars", 48678219.0);
		planetMap.put("jupiter", 390674710.0);
		planetMap.put("saturn", 792248270.0);
		planetMap.put("uranus", 1692662530.0);
		planetMap.put("neptune", 2703959960.0);
		
		travelMap = new HashMap<String, Double>();
		travelMap.put("Walking", 3.0);
		travelMap.put("Car", 100.0);
		travelMap.put("Bullet Train", 200.0);
		travelMap.put("Boeing 747", 570.0);
		travelMap.put("Concord", 1350.0);
		
		Double years = planetMap.get(planet) / travelMap.get(methodOfTransportation) / 24 / 365.26;
		Double newAge = years + age;
		
		String result = "Travelling by " + methodOfTransportation + " you will reach " + planet.substring(0, 1).toUpperCase() + planet.substring(1) + " in " + df.format(years) + " years. You will be " + df.format(newAge) + " years old." ;
		return result;
	}
}
