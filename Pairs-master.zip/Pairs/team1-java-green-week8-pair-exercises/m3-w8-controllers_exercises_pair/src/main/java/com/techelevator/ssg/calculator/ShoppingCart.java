package com.techelevator.ssg.calculator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.techelevator.ssg.model.store.JdbcProductDao;
import com.techelevator.ssg.model.store.Product;

public class ShoppingCart {
	
	private Map<Long, Product> newList;
	
	public Map<Long, Product> getNewList() {
		return newList;
	}

	public ShoppingCart updateShoppingCart(Long productId, int quantity, Product product, Map<Long, Product> newList, ShoppingCart shopCart){
		this.newList = newList;
		
		if (newList.containsKey(productId)) {
			product.setQuantity(newList.get(productId).getQuantity() + quantity);
			
		} else if (!newList.containsKey(productId)) {
			product.setQuantity(quantity);			
		}
		
		newList.put(productId, product);
		return shopCart;
		
	}
	public double getGrandTotal() {
		double total = 0;		
		for (Product product : newList.values()) {
		  total += (double)product.getTotalFromQuantity() ;
		}
				
		return total;
	}
 }
