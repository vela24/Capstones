package com.techelevator.ssg.controller;

	import java.time.LocalDateTime;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.techelevator.ssg.model.forum.ForumPost;
import com.techelevator.ssg.model.forum.JdbcForumDao;
	
	@Controller
	public class ForumController {

		@Autowired
		private JdbcForumDao jdbcForumDao;
		
		@RequestMapping(path="/forumView", method=RequestMethod.GET)
		public String displayForumViewPage(HttpServletRequest request) {
			request.setAttribute("Posts", jdbcForumDao.getAllPosts());
			return "forumView";
		}
		
		@RequestMapping(path="/forumPost", method=RequestMethod.GET)
		public String displayForumPostPage(HttpServletRequest request) {	
			return "forumPost";
		}
		
		@RequestMapping(path="/forumPost", method=RequestMethod.POST)
		public String postNewForum(ForumPost forumPost, @RequestParam String username, 
				@RequestParam String subject, @RequestParam String message, HttpServletRequest request) {
			
			forumPost.setUsername(username);
			forumPost.setSubject(subject);
			forumPost.setMessage(message);
			forumPost.setDatePosted(LocalDateTime.now());
			
			jdbcForumDao.save(forumPost);

			return "redirect:/forumView";
		}
}
