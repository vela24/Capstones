package com.techelevator.ssg.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.techelevator.ssg.calculator.Calculator;



@Controller
public class HomeController {
	Calculator calculator = new Calculator();
	
	@RequestMapping("/")
	public String displayHomePage() {
		return "homePage";
	}
	
	@RequestMapping("/alienAgeInput")
	public String displayAlienAgeInputPage(HttpServletRequest request) {
		return "alienAgeInput";
	}
	
	@RequestMapping("/alienWeightInput")
	public String displayAlienWeightInputPage(HttpServletRequest request) {
		return "alienWeightInput";
	}
	
	@RequestMapping("/driveTimeInput")
	public String displayDriveTimeInputPage(HttpServletRequest request) {
		return "driveTimeInput";
	}
	
	@RequestMapping("/alienAgeResult")
	public String displayAlienAge(HttpServletRequest request) {
		
		String planet = (request.getParameter("planet"));
		Double age = Double.parseDouble(request.getParameter("age"));
		String result = calculator.alienAge(planet, age);
		
		request.setAttribute("Result", result);
		return "alienAgeResult";
	}
	
	@RequestMapping("/alienWeightResult")
	public String displayAlienWeight(HttpServletRequest request) {
		String planet = (request.getParameter("planet"));
		Double lbsOnEarth = Double.parseDouble(request.getParameter("lbsOnEarth"));
		
		request.setAttribute("Result", calculator.alienWeight(planet, lbsOnEarth));
		return "alienWeightResult";
	}
	
	@RequestMapping("/driveTimeResult")
	public String displayDriveTime(HttpServletRequest request) {
		String planet = (request.getParameter("planet"));
		String methodOfTransportation = (request.getParameter("transportation"));
		Double age = Double.parseDouble(request.getParameter("age"));
		
		
		request.setAttribute("Result", calculator.driveTime(planet, methodOfTransportation, age));
		return "driveTimeResult";
	}
}
