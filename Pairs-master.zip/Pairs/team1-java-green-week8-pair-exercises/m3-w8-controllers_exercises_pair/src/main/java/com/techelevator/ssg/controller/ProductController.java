package com.techelevator.ssg.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.techelevator.ssg.calculator.ShoppingCart;
import com.techelevator.ssg.model.forum.JdbcForumDao;
import com.techelevator.ssg.model.store.JdbcProductDao;
import com.techelevator.ssg.model.store.Product;

@Controller
@SessionAttributes ("ShoppingCart")
public class ProductController {
	
	@Autowired
	private JdbcProductDao jdbcProductDao;
	
	@RequestMapping(path="/productList", method=RequestMethod.GET)
	
	public String displayProductListPage(HttpServletRequest request) {
		request.setAttribute("products", jdbcProductDao.getAllProducts());
		return "productList";
		
	}
	@RequestMapping(path="/productDetail", method=RequestMethod.GET)
	public String displayProductDetail(@RequestParam Long productId, HttpServletRequest request) {
		request.setAttribute("product", jdbcProductDao.getProductById(productId)); 
		
		return "productDetail";
	}

	@RequestMapping(path="/productDetail", method=RequestMethod.POST)
	public String addToShoppingCart(@RequestParam int quantity, @RequestParam Long productId, Product product, ShoppingCart shopCart, ModelMap map) {
		
		Map<Long, Product> newList = null;
		product = jdbcProductDao.getProductById(productId);
		
		if (map.get("ShoppingCart") != null) {	
			shopCart = (ShoppingCart) map.get("ShoppingCart");
			newList = shopCart.getNewList();
			
		} else if (map.get("ShoppingCart") == null) {
			newList = new HashMap<Long, Product>();
		}
		shopCart = shopCart.updateShoppingCart(productId, quantity, product, newList, shopCart);

		map.addAttribute("ShoppingCart", shopCart);
		
		return "redirect:/addCart";
		
	}
	@RequestMapping(path="/addCart", method=RequestMethod.GET)
	public String showShoppingCart(HttpServletRequest request) {
		return "addCart";
	}
	
	
	
	
//	@Controller
//	public class ForumController {
//
//		@Autowired
//		private JdbcForumDao jdbcForumDao;
//		
//		@RequestMapping(path="/forumView", method=RequestMethod.GET)
//		public String displayForumViewPage(HttpServletRequest request) {
//			request.setAttribute("Posts", jdbcForumDao.getAllPosts());
//			return "forumView";
//		}
//		
//		@RequestMapping(path="/forumPost", method=RequestMethod.GET)
//		public String displayForumPostPage(HttpServletRequest request) {	
//			return "forumPost";
//		}
	

}
