package com.techelevator;
import java.util.Scanner;
import java.io.File;
import java.time.format.DateTimeFormatter;
import java.io.PrintWriter;
import java.io.FileNotFoundException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class SalesReport {
	private File logFile = new File("Log.txt");
	private PrintWriter log;
	private File salesReportFile = new File("SalesReportFile.csv");
	private PrintWriter salesReportWriter;
	private Inventory inventory = new Inventory();
	private double currentFunds;
	private double pastFunds;
	
	public SalesReport() {
		try {
			log = new PrintWriter(logFile);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		
		} try {
			salesReportWriter = new PrintWriter(salesReportFile);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
	}
	public double pastFunds() {
		return this.pastFunds = currentFunds - inventory.getPrice(keyValue));
				
	}
	
	public void log(String method, double currentFunds, double pastFunds ) {
		LocalDateTime timestamp = LocalDateTime.now();
		DateTimeFormatter formatted = DateTimeFormatter.ofPattern("MM/dd/yyyy hh:mm:ss a");
		String toLog = timestamp.format(formatted) + " " + method + " " + pastFunds + " " + currentFunds;
		log.println(toLog);
		log.flush();
	}
	
	public void salesReport (VendingMachine vendingMachine) {
		String formatted;
		formatted = String.format("Item, numberSold", vendingMachine.getItemsSold().toString());
		for(Item item : vendingMachine.getItemsSold()) {
			formatted = String.format("%s, %d", item.getItemName(), item.getItemsSold());
			salesReportWriter.println(formatted);
		}
		salesReportWriter.flush();
		List<String> report = new ArrayList();
		report.add("/Users/tvela/Development/Pairs/team3-java-green-week4-pair-exercises"); // change to ben
		report.add("/Users/tvela/Development/Pairs/team3-java-green-week4-pair-exercises/m1-module1-capstone"); // change to ben
		ProcessBuilder pb = new ProcessBuilder();
		
		
	}
	
	

}
