package Bank;

import java.math.BigDecimal;

public class CheckingAccount extends BankAccount {

	public static final BigDecimal OVER_DRAFT_FEE = new BigDecimal("10.00");

	public CheckingAccount(String acct) {
		super(acct);
	}

	
	public BigDecimal withdraw(BigDecimal amountToWithdraw) {
		
		double comparisonHolder = getBalance().doubleValue() - amountToWithdraw.doubleValue();
		
		//handles the case if account will be more than 100 overdrawn
		if(comparisonHolder <= -100) {
			return super.withdraw(new BigDecimal("0.00"));
		}
		
		//if cH = 0 even, if cH = 1 less than, if cH = -1 greater than
		int compareHolder = getBalance().compareTo(new BigDecimal ("0.00")); 
		
		if((compareHolder == 0 ||compareHolder == 1) && (comparisonHolder >= -80.00 && comparisonHolder < 0)) {    // if current balance < 0
			return super.withdraw(OVER_DRAFT_FEE.add(amountToWithdraw));
		} else {
			return super.withdraw(amountToWithdraw);
		}
	}
}
