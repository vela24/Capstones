package Bank;

import java.math.BigDecimal;

public class SavingsAccount extends BankAccount{

	private final BigDecimal serviceFee = new BigDecimal("2.00");
	
	public SavingsAccount(String SavingsAcct) {
		super(SavingsAcct);
	}
	
	public BigDecimal withdraw(BigDecimal amountToWithdraw) {
		BigDecimal currentBalance = getBalance();

		if(currentBalance.compareTo(amountToWithdraw) == -1) {
			return super.withdraw(new BigDecimal("0.00"));
		}
		
		if(currentBalance.compareTo(new BigDecimal("150.00")) == -1) {
			return super.withdraw(serviceFee.add(amountToWithdraw));
		}
		else {
			return super.withdraw(amountToWithdraw);
		}
	}
}
