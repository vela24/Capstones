package Bank;

import static org.junit.Assert.*;

import java.math.BigDecimal;

import org.junit.Assert;
import org.junit.Test;

import Bank.BankAccount;

public class BankAccountTest {
	
	@Test
	public void testConstructor() {
		String acct = null;
		BankAccount bank = new BankAccount(acct);
		Assert.assertNotNull(bank);
	}
	
	@Test
	public void deposit() {
		String acct = "99999";
		BankAccount bankAccount1 = new BankAccount(acct);
		BigDecimal amt = new BigDecimal("100.00");
		Assert.assertEquals(new BigDecimal("100.00"), bankAccount1.deposit(amt));
	}
	
	@Test
	public void testWithdraw() {
		String acct = "12345";
		BankAccount bankAccount1 = new BankAccount(acct);
		bankAccount1.deposit(new BigDecimal("200.00"));
		BigDecimal amt = new BigDecimal("100.00");
		Assert.assertEquals(new BigDecimal("100.00"), bankAccount1.withdraw(amt));
	}
	
	@Test 
	public void testTransfer() {
		String acct = "11111";
		BankAccount bankAccount1 = new BankAccount(acct);
		bankAccount1.deposit(new BigDecimal("200.00"));
		String acct1 = "22222";
		BankAccount bankAccount2 = new BankAccount(acct1);
		bankAccount2.deposit(new BigDecimal("20.00"));
		BigDecimal amt = new BigDecimal("100.00");
		
		bankAccount1.transfer(bankAccount2, amt);
		Assert.assertEquals("Expecting acct 2 to have $120: ", new BigDecimal("120.00"), bankAccount2.getBalance());
		Assert.assertEquals("Expecting acct 2 to have $100: ", new BigDecimal("100.00"), bankAccount1.getBalance());
	}
	
	


}
