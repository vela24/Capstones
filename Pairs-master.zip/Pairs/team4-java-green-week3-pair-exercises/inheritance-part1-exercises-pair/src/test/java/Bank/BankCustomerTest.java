package Bank;

import static org.junit.Assert.*;

import java.math.BigDecimal;

import org.junit.Assert;
import org.junit.Test;

public class BankCustomerTest {
	
	@Test
	public void testConstructor() {
		String name = "Diana Copeland";
		String address = "111 Little Lane";
		String phoneNumber = "1111111111";
		BankCustomer bc = new BankCustomer(name, address, phoneNumber);
		Assert.assertNotNull(bc);
	}

	@Test
	public void testAddAccount() {
		String acctNum = "12345";
		SavingsAccount acct = new SavingsAccount(acctNum);
		Assert.assertNotNull(acct);
		CheckingAccount acct2 = new CheckingAccount(acctNum);
		Assert.assertNotNull(acct2);
		String name = "Tad Vela";
		String address = "111 Little Lane";
		String phoneNumber = "1111111111";
		BankCustomer bc = new BankCustomer(name, address, phoneNumber);
		Assert.assertNotNull(bc);
		
		bc.addAccount(acct);
		bc.addAccount(acct2);
		BankAccount[] bka = {acct, acct2};
		Assert.assertArrayEquals(bka, bc.getAccounts());
		
		acctNum = "245";
		CheckingAccount chk = new CheckingAccount(acctNum);
		bc.addAccount(chk);
		BankAccount[] bka2 = {acct, acct2, chk};
		Assert.assertArrayEquals(bka2, bc.getAccounts());
	}
	
	@Test
	public void testValidation() {
		String name = "Diana Copeland";
		String address = "111 Little Lane";
		String phoneNumber = "1111111111";
		BankCustomer bc = new BankCustomer(name, address, phoneNumber);
		Assert.assertNotNull(bc);
		Assert.assertEquals("Diana Copeland", bc.getName());
		Assert.assertEquals("111 Little Lane", bc.getAddress());
		Assert.assertEquals("1111111111", bc.getPhoneNumber());
	}
	
	@Test
	public void isVip() {
		String acctNum = "12345";
		SavingsAccount acct = new SavingsAccount(acctNum);
		Assert.assertNotNull(acct);
		acct.deposit(new BigDecimal("15000.00"));
		CheckingAccount acct2 = new CheckingAccount(acctNum);
		Assert.assertNotNull(acct2);
		acct2.deposit(new BigDecimal("15000.00"));
		String name = "Tad Vela";
		String address = "111 Little Lane";
		String phoneNumber = "1111111111";
		BankCustomer bc = new BankCustomer(name, address, phoneNumber);
		Assert.assertNotNull(bc);
	
		bc.addAccount(acct);
		bc.addAccount(acct2);
		
		bc.getAccountTotals();
		Assert.assertTrue("Should be true 30,000 total accounts: ", bc.isVip);
	}
	
}
