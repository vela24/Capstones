package Bank;

import static org.junit.Assert.*;

import java.math.BigDecimal;

import org.junit.Assert;
import org.junit.Test;

public class CheckingAccountTest {
	
	/**
	 * test constructor to ensure it is not null
	 */
	@Test
	public void testConstructor() {
		String acct = null;
		CheckingAccount chk = new CheckingAccount(acct);
		Assert.assertNotNull(chk);
	}
	
	
	/**
	 * this test will deposit 100.00, withdraw 105 and should be allowed leaving the acct with -15. 
	 */
	@Test
	public void testWithdrawWithPosNeg() {
		String acct = null;
		CheckingAccount checkingAccount2 = new CheckingAccount(acct);
		BigDecimal amt1 = new BigDecimal("100.00");
		checkingAccount2.deposit(amt1);
		BigDecimal amt2 = new BigDecimal("105.00");
		Assert.assertEquals(new BigDecimal("-15.00"), checkingAccount2.withdraw(amt2));
	}
	
	
	/**
	 * Test if there is money and attempt to overdraw and the case there is money but 
	 * overdrawing will make it more than -100
	 */
	@Test
	public void positiveHappyPathWithdrawal() {
		String acct = null;
		CheckingAccount checkingAccount3 = new CheckingAccount(acct);
		BigDecimal amt3 = new BigDecimal("20.00");
		checkingAccount3.deposit(amt3);
		BigDecimal amt4 = new BigDecimal("125.00");
	
		Assert.assertEquals(new BigDecimal("20.00"), checkingAccount3.withdraw(amt4));
		BigDecimal amt5 = new BigDecimal("10.00");
		Assert.assertEquals(new BigDecimal("10.00"), checkingAccount3.withdraw(amt5));
	}
	
	
	/**
	 * this will test if I have zero dollars and attempt to withdraw 100 (bal should be 0)
	 * If I have zero dollars and attempt to withdraw 40 (bal should be -50)
	 */
	@Test
	public void withdrawalWithZeroAmount() {
		String acct = null;
		CheckingAccount checkingAccount1 = new CheckingAccount(acct);
		BigDecimal amt = new BigDecimal("100.00");
		Assert.assertEquals(new BigDecimal("0.00"), checkingAccount1.withdraw(amt));
		
		BigDecimal amt1 = new BigDecimal("40.00");
		Assert.assertEquals(new BigDecimal("-50.00"), checkingAccount1.withdraw(amt1));
	}
	


}
