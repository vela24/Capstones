package Bank;

import static org.junit.Assert.*;

import java.math.BigDecimal;

import org.junit.Test;
import org.junit.Assert;

public class SavingsAccountTest {

	
	/**
	 * test constructor to ensure it is not null
	 */
	@Test
	public void testConstructor() {
		String acct = "123";
		SavingsAccount save = new SavingsAccount(acct);
		Assert.assertNotNull(save);
	}
	
	
	/**
	 * this test will deposit 100.00, then attempt a withdraw resulting in a $2.00 service fee
	 * also tests if the balance == $150 and withdraw is made resulting in no service fee
	 */
	@Test
	public void testWithdrawServiceFee() {
		String acct = "1234";
		SavingsAccount sa2 = new SavingsAccount(acct);
		BigDecimal amt1 = new BigDecimal("100.00");
		sa2.deposit(amt1);
		BigDecimal amt2 = new BigDecimal("70.00");
		Assert.assertEquals(new BigDecimal("28.00"), sa2.withdraw(amt2));
		
		acct = "2234";
		sa2 = new SavingsAccount(acct);
		amt1 = new BigDecimal("150.00");
		sa2.deposit(amt1);
		amt2 = new BigDecimal("70.00");
		Assert.assertEquals(new BigDecimal("80.00"), sa2.withdraw(amt2));	
	}
	
	
	/**
	 * Test withdraws that are more than the current balance 
	 * 
	 */
	@Test
	public void testWithdrawOverBalance() {
		String acct = "1234";
		SavingsAccount sa3 = new SavingsAccount(acct);
		BigDecimal amt3 = new BigDecimal("20.00");
		sa3.deposit(amt3);
		BigDecimal amt4 = new BigDecimal("125.00");
		Assert.assertEquals("Expecting balance to be $20", new BigDecimal("20.00"), sa3.withdraw(amt4));
	}
	
	
	/**
	 * this will test happy paths only
	 * 
	 */
	@Test
	public void testHappyPaths() {
		String acct = "2222";
		SavingsAccount sa4 = new SavingsAccount(acct);
		sa4.deposit(new BigDecimal("300.00"));
		BigDecimal amt = new BigDecimal("200.00");
		Assert.assertEquals(new BigDecimal("100.00"), sa4.withdraw(amt));
		
		sa4.deposit(new BigDecimal(100.00));
		BigDecimal amt1 = new BigDecimal("40.00");
		Assert.assertEquals(new BigDecimal("160.00"), sa4.withdraw(amt1));
	}
	

}
