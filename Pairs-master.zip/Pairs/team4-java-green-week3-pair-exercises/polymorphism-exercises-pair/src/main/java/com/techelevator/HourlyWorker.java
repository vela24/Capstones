package com.techelevator;

public class HourlyWorker implements Worker {
	String firstName;
	String lastName;
	double hourlyRate;
	
	HourlyWorker(String firstName, String lastName, double hourlyRate){
		this.firstName = firstName;
		this.lastName = lastName;
		this.hourlyRate = hourlyRate;
	}
	
	@Override
	public String getFirstName() {
		// TODO Auto-generated method stub
		return this.firstName;
	}

	@Override
	public String getLastName() {
		// TODO Auto-generated method stub
		return this.lastName;
	}

	@Override
	public double calculateWeeklyPay(int hoursWorked) {
		double weeklyPay = 0, overtime = 0 ;
		
		if(hoursWorked > 40) {
			weeklyPay = hourlyRate * hoursWorked;
			overtime = hoursWorked - 40;
			weeklyPay = weeklyPay + (hourlyRate * overtime * .5);
		} else {
			weeklyPay = hourlyRate * hoursWorked;
		}
		
		return weeklyPay;
	}

}
