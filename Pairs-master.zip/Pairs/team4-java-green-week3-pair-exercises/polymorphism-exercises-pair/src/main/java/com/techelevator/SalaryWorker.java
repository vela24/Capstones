package com.techelevator;

public class SalaryWorker implements Worker {
	double annualSalary;
	String firstName;
	String lastName;
	
	public SalaryWorker(String firstName, String lastName, double annualSalary) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.annualSalary = annualSalary;
	}

	@Override
	public String getFirstName() {
		// TODO Auto-generated method stub
		return this.firstName;
	}

	@Override
	public String getLastName() {
		// TODO Auto-generated method stub
		return this.lastName;
	}
	
	@Override
	public double calculateWeeklyPay(int hoursWorked) {
		// TODO Auto-generated method stub
		double weeklyPay = (this.annualSalary / 52);
		return weeklyPay;
	}

	public double getAnnualSalary() {
		return annualSalary;
	}	

}
