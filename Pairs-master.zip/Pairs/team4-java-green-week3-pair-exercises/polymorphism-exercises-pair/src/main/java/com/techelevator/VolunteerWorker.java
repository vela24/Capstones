package com.techelevator;

public class VolunteerWorker implements Worker {

	private int hoursWorked;
	private String firstName, lastName;
	
	public VolunteerWorker(String firstName, String lastName) {
		// TODO Auto-generated constructor stub
		this.firstName = firstName;
		this.lastName = lastName;
	}

	
	@Override
	public String getFirstName() {
		// TODO Auto-generated method stub
		return this.firstName;
	}

	@Override
	public String getLastName() {
		// TODO Auto-generated method stub
		return this.lastName;
	}

	@Override
	public double calculateWeeklyPay(int hoursWorked) {
		// TODO Auto-generated method stub
		return hoursWorked * 0;
	}

}
