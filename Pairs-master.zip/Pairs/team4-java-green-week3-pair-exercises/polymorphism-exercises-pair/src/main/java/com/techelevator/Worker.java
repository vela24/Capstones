package com.techelevator;

public interface Worker {

	String getFirstName();
	String getLastName();
	
	double calculateWeeklyPay(int hoursWorked);
}
