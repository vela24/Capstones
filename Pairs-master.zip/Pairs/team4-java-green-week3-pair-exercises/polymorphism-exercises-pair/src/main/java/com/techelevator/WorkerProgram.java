package com.techelevator;

import java.util.List;
import java.text.DecimalFormat;
import java.util.ArrayList;

public class WorkerProgram {
	
	public static void main(String[] args) {
		List<Worker> workers = new ArrayList<Worker>();
		int sumHours = 0;
		double sumPay = 0;
		DecimalFormat df = new DecimalFormat("0.00");
		
		VolunteerWorker vol = new VolunteerWorker("Sam", "Smith");
		SalaryWorker salary = new SalaryWorker("Scott", "Last", 50000.00);
		HourlyWorker hourly = new HourlyWorker("Yogi", "Bare", 10.00);
		
		workers.add(vol);
		workers.add(salary);
		workers.add(hourly);
		
		int randomHours;
		
		System.out.println("Employee\tHours Worked\tPay" );
		for(Worker w : workers) {
			randomHours = (int) Math.ceil(Math.random() *125);
			System.out.println(w.getLastName() + ", " + w.getFirstName() + "\t" + randomHours + "\t\t" + df.format(w.calculateWeeklyPay(randomHours)));
			sumHours += randomHours;
			sumPay += w.calculateWeeklyPay(randomHours);
		}
		
		System.out.println();
		System.out.println("Total Hours: " + sumHours);
		System.out.println("Total Pay: " + df.format(sumPay));
		
	}

}
