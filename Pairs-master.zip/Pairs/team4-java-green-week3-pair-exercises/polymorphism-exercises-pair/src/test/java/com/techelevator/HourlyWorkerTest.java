package com.techelevator;

import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.Assert;

public class HourlyWorkerTest {

	@Test
	public void testConstructor() {
		HourlyWorker vw = new HourlyWorker("D", "C", 12.00);
		Assert.assertNotNull(vw);
	}
	
	@Test
	public void testPay() {
		HourlyWorker vw = new HourlyWorker("Tad", "Vela", 12.00);
		Assert.assertNotNull(vw);
		Assert.assertEquals("Expecting $840: ", 840, vw.calculateWeeklyPay(60), .01);
		Assert.assertEquals("Expecting $480: ", 480, vw.calculateWeeklyPay(40), .01);
	}
	
	@Test
	public void testAllMethods() {
		HourlyWorker vw = new HourlyWorker("Tad", "Vela", 10.00);
		Assert.assertNotNull(vw);
		Assert.assertEquals("Tad", vw.getFirstName());
		Assert.assertEquals("Vela", vw.getLastName());
		Assert.assertEquals("Expecting $250.00: ", 250.00, vw.calculateWeeklyPay(25), .01);
		
		HourlyWorker hw = new HourlyWorker("D", "C", 10.00);
		Assert.assertNotNull(hw);
		Assert.assertEquals("D", hw.getFirstName());
		Assert.assertEquals("C", hw.getLastName());
		Assert.assertEquals("Expecting 100.00: ", 100.00, hw.calculateWeeklyPay(10), .01);
	}
}
