package com.techelevator;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

public class SalaryWorkerTest {
	
	@Test
	public void testConstructor() {
		SalaryWorker vw = new SalaryWorker("D", "C", 70000.00);
		Assert.assertNotNull(vw);
	}
	
	@Test
	public void testPay() {
		SalaryWorker vw = new SalaryWorker("Tad", "Vela", 75000.00);
		Assert.assertNotNull(vw);
		Assert.assertEquals("Expecting $1442.30: ", 1442.30, vw.calculateWeeklyPay(40), .01);
	}
	
	@Test
	public void testAllMethods() {
		SalaryWorker vw = new SalaryWorker("Tad", "Vela", 75000.00);
		Assert.assertNotNull(vw);
		Assert.assertEquals("Tad", vw.getFirstName());
		Assert.assertEquals("Vela", vw.getLastName());
		Assert.assertEquals("Expecting $1442.30: ", 1442.30, vw.calculateWeeklyPay(25), .01);
	}
}
