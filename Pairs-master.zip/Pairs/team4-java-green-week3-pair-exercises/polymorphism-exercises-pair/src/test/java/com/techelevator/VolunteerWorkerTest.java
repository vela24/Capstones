package com.techelevator;

import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.Assert;

public class VolunteerWorkerTest {

	@Test
	public void testConstructor() {
		VolunteerWorker vw = new VolunteerWorker("D", "C");
		Assert.assertNotNull(vw);
	}
	
	@Test
	public void testPay() {
		VolunteerWorker vw = new VolunteerWorker("Tad", "Vela");
		Assert.assertNotNull(vw);
		Assert.assertEquals("Expecting $0.00: ", 0.00, vw.calculateWeeklyPay(40), .00001);
	}
	
	@Test
	public void testAllMethods() {
		VolunteerWorker vw = new VolunteerWorker("Tad", "Vela");
		Assert.assertNotNull(vw);
		Assert.assertEquals("Tad", vw.getFirstName());
		Assert.assertEquals("Vela", vw.getLastName());
		Assert.assertEquals("Expecting $0.00: ", 0.00, vw.calculateWeeklyPay(25), .00001);
	}
}
